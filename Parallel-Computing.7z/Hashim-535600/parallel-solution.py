import os
import time

import utility as ut
from pyspark import SparkContext

# number of nodes
NODES = 4

# number of paritions
# it is better to have more partitions than nodes in case some nodes completed
# their tasks before others but since we are using single computer with 4 cores only
# we found best to use 4 PARTITIONS only

PARTITIONS = NODES * 1

# absolute path to where data is located on HD (hard disk)
PATH = ""

# defining number of nodes
sc = SparkContext("local[" + str(NODES) + "]", "MoviesSerialSolution")
# saving get_movies result in movies variable
movies = ut.get_movies(os.path.join(PATH, 'C:/SparkCourse/hw/u.item'))
# reading data file using spark and distribute it over specific number of partitions
rdd = sc.textFile(os.path.join(PATH, 'C:/SparkCourse/hw/u.data'), PARTITIONS)

movies_rated = rdd.map(lambda line: line.split()). \
    map(lambda column: (int(column[1]), 1))
# Now we have a to count number of occurrences for each movieID
movie_counts = movies_rated.reduceByKey(lambda x, y: x + y)
# we have the number of occurrences for each movie, we only need to sort these pairs based on occurrences
sorted_movies = movie_counts.sortBy(lambda x: x[1], False)

sorted_movies_names = sorted_movies. \
    map(lambda movie: (movie[0], (movies[movie[0]], movie[1]))).collect()

target_movie = sorted_movies_names[0]
#print(str(target_movie[0]) + ' ' + str(target_movie[1][0]))

# 2 - People who watched Target Movie and other movies and gave rating
# this mapping is useful for 2nd and 3rd assignment
ratings = rdd.map(lambda line: line.split()).map(lambda line: (int(line[0]), (int(line[1]), float(line[2])))).cache()
# first we filter for people who voted for target movie
filtered_users = ratings.filter(lambda rating: rating[1][0] == target_movie[0]).map(lambda rating: rating[0]).collect()

# then we filter for movies voted by filtered users
filtered_movies = ratings.filter(lambda rating: rating[0] in filtered_users)

filtered_movies_names = filtered_movies.map(
    lambda column: (int(column[0]), movies[column[1][0]]))

# now we group by userID
user_movies = filtered_movies_names.groupByKey().mapValues(list)

#user_movies.saveAsTextFile("user-movies-parallel")
# user_movies.collect()
# for user_movie in user_movies:
#     print(user_movie)


# 3 - Find similarities between popular movie and other movies
# we use self-join to find all combinations.
# hint: ratings already calculated previously and cached
joined_ratings = ratings.join(ratings)

# Now we have the following mapping: userID -> ((movieID, rating), (movieID, rating))
# we now remove duplicates that obtained from the cartesian product
filtered_ratings = joined_ratings.filter(ut.filter_duplicates)

# change mapping of userID -> ((movie1,rating1),(movie2,rating2)) To ((movie1,movie2),(rating1,rating2))
movie_rating_pairs = filtered_ratings.map(ut.remake_movie_rating_pairs)

# Now we group by key "(movie1,movie2)" to get all ratings for this pair
# we mean we will obtain the mapping: (movie1, movie2) = > (rating1, rating2), (rating1, rating2) ...
movie_ratings_pairs = movie_rating_pairs.groupByKey()

# We can now compute similarities.
# using mapValues will let us change work on values only
movie_pair_similarity = movie_ratings_pairs.mapValues(ut.compute_similarity).cache()
#
THRESH = 0.80
CO_OCCURRENCE_THRESH = 20
# Filter movies on threshold an co-occurrence threshold
pre_results = movie_pair_similarity.filter(lambda pair:
                                           (pair[0][0] == target_movie[0] or pair[0][1] == target_movie[0]) and
                                           pair[1][0] > THRESH and pair[1][1] > CO_OCCURRENCE_THRESH)

# sort results by score in descending order
final_results = pre_results.sortBy(lambda x: x[1], False).take(10)

print("Top 10 movies which are similar to movie: " + target_movie[1][0])
for result in final_results:
    other_movie_id = result[0][0]
    if (other_movie_id == target_movie[0]):  # in case we result[0][0] was target_movie
        other_movie_id = result[0][1]
    print(movies[other_movie_id] + "\t\tScore: " + str(result[1][0]) + "\t\tOccurrence number: " +
          str(result[1][1]))

exc_time = (time.time() * 1000 - float(sc.startTime)) / 1000
print('Time of execution is: ' + str(exc_time))
