import os
import time

import utility as ut

start = time.time()
PATH = ""

# saving get_movies result in movies variable
movies = ut.get_movies(os.path.join(PATH, 'u.item'))
# reading data files
data = ut.get_data(os.path.join(PATH, 'u.data'))
data = map(lambda line: line.split(), data)

# Now let's start finding the Target Movie-----Popular Movie
# 1 - Most rated movie
movies_rated = map(lambda column: (int(column[1]), 1), data)
# Now we have a to count number of occurrences for each movieID
# implemented our own group_by_key
movie_counts = [(key, len(value)) for key, value in ut.group_by_key(movies_rated)]
# we have the number of occurrences for each movie, we only need to sort these pairs based on occurrences
sorted_movies = sorted(movie_counts, key=lambda x: x[1], reverse=True)

sorted_movies_names = map(lambda movie: (movie[0], (movies[movie[0]], movie[1])), sorted_movies)

target_movie = sorted_movies_names[0]
#(str(target_movie[0]) + ' ' + str(target_movie[1][0]))

# 2 - People who watched Target Movie and other movies and gave rating
ratings = map(lambda col: (int(col[0]), (int(col[1]), float(col[2]))), data)
# first we filter for people who voted for target movie
filtered_users = map(lambda rating: rating[0],
                     filter(lambda rating: rating[1][0] == target_movie[0], ratings))

# then we filter for movies voted by filtered users
filtered_movies = filter(lambda rating: rating[0] in filtered_users, ratings)

filtered_movies_names = map(lambda column: (int(column[0]), movies[column[1][0]]), filtered_movies)
# now we group by userID
user_movies = ut.group_by_key(filtered_movies_names)
# for user_movie in user_movies:
#     print(user_movie)
#with open('user-movies-serial', 'w') as f:
    #for item in user_movies:
        #f.write("%s\n" % str(item))

# 3 - Find similarities between popular movie and other movies
# we use self-join to find all combinations.
joined_ratings = [(k, (v, _v)) for k, v in ratings for _k, _v in ratings if k == _k]
# Now we have the following mapping: userID -> ((movieID, rating), (movieID, rating))
# we now remove duplicates that obtained from the cartesian product
filtered_ratings = filter(ut.filter_duplicates, joined_ratings)
# change mapping of userID -> ((movie1,rating1),(movie2,rating2)) To ((movie1,movie2),(rating1,rating2))
movie_rating_pairs = map(ut.remake_movie_rating_pairs, filtered_ratings)
# Now we group by key "(movie1,movie2)" to get all ratings for this pair
# we mean we will obtain the mapping: (movie1, movie2) = > (rating1, rating2), (rating1, rating2) ...
movie_ratings_pairs = ut.group_by_key(movie_rating_pairs)
# We can now compute similarities.
# using list comprehension we calculate similarity for each movie pair i,e (movie1,movie2)
movie_pair_similarity = [(key, ut.compute_similarity(value)) for key, value in movie_ratings_pairs]
#
THRESH = 0.80
CO_OCCURRENCE_THRESH = 20
# Filter movies on threshold an co-occurrence threshold
pre_results = filter(lambda pair: (pair[0][0] == target_movie[0] or pair[0][1] == target_movie[0]) and
                                  pair[1][0] > THRESH and pair[1][1] > CO_OCCURRENCE_THRESH, movie_pair_similarity)

# sort results by score in descending order
final_results = sorted(pre_results, key=lambda x: x[1], reverse=True)[:10]  # take first 10

print("Top 10 movies which are similar to movie: " + target_movie[1][0])
for result in final_results:
    other_movie_id = result[0][0]
    if (other_movie_id == target_movie[0]):  # in case we result[0][0] was target_movie
        other_movie_id = result[0][1]
    print(movies[other_movie_id] + "\t\tScore: " + str(result[1][0]) + "\t\tOccurrence number: " +
          str(result[1][1]))
end = time.time()

print('Time of execution is: ' + str(end - start))
