import os

# return dictionary of ([key] -> value) pairs of movieID and movieName, since we need only movieID and movieName
# and all other info about a movie is unimportant
from math import sqrt


def get_data(path):
    data = []
    # check if file path is valid
    if (os.path.isfile(path)):
        # opening file and iterating over lines
        with open(path) as f:
            data = f.readlines()
    else:
        print("File: " + path + " could not be found in your system")
    return data


def get_movies(path):
    movies_dict = {}

    # check if file path is valid
    if (os.path.isfile(path)):
        # opening file and iterating over lines
        with open(path) as f:
            for line in f:
                # Split the lines
                cols = line.split('|')
                # saving key(movieID)->value(movieName) relation within movies dictionary
                movies_dict[int(cols[0])] = cols[1]
    else:
        print("File: " + path + " could not be found in your system")
    return movies_dict


def ratings_avg(ratings):
    return sum(ratings) / len(ratings)


def remake_movie_rating_pairs(user_rating):
    movie_rating = user_rating[1]
    (movie1, rating1) = movie_rating[0]
    (movie2, rating2) = movie_rating[1]
    return ((movie1, movie2), (rating1, rating2))


def filter_duplicates(user_ratings):
    ratings = user_ratings[1]
    (movie, rating) = ratings[0]
    (_movie, _rating) = ratings[1]
    return movie < _movie


def compute_similarity(pairs):
    cnt = 0
    sum_1 = sum_2 = sum_12 = 0
    for rating1, rating2 in pairs:
        sum_1 += rating1 * rating1
        sum_2 += rating2 * rating2
        sum_12 += rating1 * rating2
        cnt += 1
    num = sum_12
    denom = sqrt(sum_1) * sqrt(sum_2)

    res = 0.0
    if (denom):
        res = num / denom

    return (res, cnt)


def group_by_key(_list):
    result = {}
    fin_res = []
    for item in _list:
        if (result.has_key(item[0])):
            result.get(item[0]).append(item[1])
        else:
            result[item[0]] = [item[1]]
    for key, value in result.iteritems():
        fin_res.append((key, value))
    return fin_res
def quiet_logs(sc):
    logger = sc._jvm.org.apache.log4j
    logger.LogManager.getLogger("org").setLevel(logger.Level.ERROR)
    logger.LogManager.getLogger("akka").setLevel(logger.Level.ERROR)
